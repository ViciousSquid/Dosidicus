"""
STDP Integration Guide for brain_widget.py

This file documents all the changes needed to integrate STDP into your
existing brain_widget.py. Rather than providing a full replacement,
this shows the specific modifications section by section.

================================================================================
STEP 1: Add Imports (near top of file, around line 17)
================================================================================
"""

# ADD these imports after the existing brain_worker import:
# from .stdp import STDPLearner, STDPConfig, create_stdp_learner


"""
================================================================================
STEP 2: Add STDP Instance Variables in __init__ (around line 130)
================================================================================
"""

# ADD after self.hebbian_countdown_seconds = 30:

"""
        # === STDP Configuration ===
        self.stdp_enabled = True  # Master toggle for STDP
        self.stdp_weight = 0.4    # Balance between STDP (0.4) and Hebbian (0.6)
        
        # Connection age tracking for STDP (newer connections learn faster)
        self.connection_creation_times = {}  # (src, dst) -> timestamp
        
        # STDP visualization settings
        self.show_stdp_direction = True  # Show directional arrows for STDP
        self.stdp_ltp_color = (76, 175, 80)   # Green for potentiation
        self.stdp_ltd_color = (244, 67, 54)   # Red for depression
"""


"""
================================================================================
STEP 3: Connect STDP Signal in _start_brain_worker (around line 351)
================================================================================
"""

# ADD after self.brain_worker.hebbian_result.connect(self._on_hebbian_complete):

"""
        # Connect STDP event signal for visualization
        if hasattr(self.brain_worker, 'stdp_event'):
            self.brain_worker.stdp_event.connect(self._on_stdp_event)
"""


"""
================================================================================
STEP 4: Add STDP Event Handler (add new method after _on_hebbian_complete)
================================================================================
"""

def _on_stdp_event(self, event: dict):
    """
    Handle STDP events from the worker thread.
    Used for visualization and debugging of timing-dependent learning.
    
    Event types:
    - 'spike': A neuron crossed the activation threshold
    - 'learning': An STDP learning event occurred (LTP or LTD)
    """
    event_type = event.get('type')
    
    if event_type == 'spike':
        # A neuron spiked - could trigger visual pulse
        neuron = event.get('neuron')
        activation = event.get('activation', 0)
        
        # Spawn a visual pulse from the spiking neuron
        if hasattr(self, '_spawn_spike_visual') and neuron in self.neuron_positions:
            self._spawn_spike_visual(neuron, activation)
    
    elif event_type == 'learning':
        # STDP learning occurred
        neurons = event.get('neurons', (None, None))
        direction = event.get('direction', 'none')
        is_ltp = event.get('is_ltp', False)
        is_ltd = event.get('is_ltd', False)
        
        n1, n2 = neurons
        if n1 and n2:
            # Determine visual direction based on STDP result
            if direction == 'n1_to_n2':
                source, target = n1, n2
            elif direction == 'n2_to_n1':
                source, target = n2, n1
            else:
                source, target = n1, n2
            
            # Create directional weight animation
            if is_ltp:
                # Potentiation - use green, show strengthening
                color = self.stdp_ltp_color if hasattr(self, 'stdp_ltp_color') else (76, 175, 80)
                self._add_stdp_animation(source, target, 'ltp', color)
            elif is_ltd:
                # Depression - use red, show weakening  
                color = self.stdp_ltd_color if hasattr(self, 'stdp_ltd_color') else (244, 67, 54)
                self._add_stdp_animation(source, target, 'ltd', color)


def _add_stdp_animation(self, source: str, target: str, learning_type: str, color: tuple):
    """
    Add a directional animation showing STDP learning.
    
    Args:
        source: Pre-synaptic neuron (fired first)
        target: Post-synaptic neuron (fired second)
        learning_type: 'ltp' or 'ltd'
        color: RGB tuple for the animation color
    """
    if source not in self.neuron_positions or target not in self.neuron_positions:
        return
    
    current_time = time.time()
    
    # Create an animated pulse traveling from source to target
    # This visually shows the causal direction of learning
    if not hasattr(self, 'stdp_animations'):
        self.stdp_animations = []
    
    self.stdp_animations.append({
        'source': source,
        'target': target,
        'type': learning_type,
        'color': color,
        'start_time': current_time,
        'duration': 0.8,  # Animation duration in seconds
        'progress': 0.0
    })
    
    # Also trigger the regular weight animation if connection exists
    pair = (source, target)
    reverse = (target, source)
    
    if pair in self.weights:
        old_w = self.weights[pair]
        delta = 0.05 if learning_type == 'ltp' else -0.03
        self.add_weight_animation(source, target, old_w, old_w + delta, color=color)
    elif reverse in self.weights:
        old_w = self.weights[reverse]
        delta = 0.05 if learning_type == 'ltp' else -0.03
        self.add_weight_animation(target, source, old_w, old_w + delta, color=color)


def _spawn_spike_visual(self, neuron: str, activation: float):
    """
    Spawn a visual effect when a neuron spikes.
    Creates a brief glow/pulse at the neuron's position.
    """
    if neuron not in self.neuron_positions:
        return
    
    # Add to spike visual queue
    if not hasattr(self, 'spike_visuals'):
        self.spike_visuals = []
    
    self.spike_visuals.append({
        'neuron': neuron,
        'activation': activation,
        'start_time': time.time(),
        'duration': 0.3
    })


"""
================================================================================
STEP 5: Modify _update_worker_cache to Include STDP Data (around line 2070)
================================================================================
"""

def _update_worker_cache(self):
    """Update the brain worker cache with current state."""
    if not hasattr(self, 'brain_worker') or not self.brain_worker:
        return
    
    # Get connector neurons
    connector_neurons = set()
    if hasattr(self, 'enhanced_neurogenesis') and self.enhanced_neurogenesis:
        connector_neurons = {
            name for name, fn in self.enhanced_neurogenesis.functional_neurons.items()
            if fn.neuron_type == 'connector'
        }
    
    # Get custom neurons (user-created)
    custom_neurons = set()
    if hasattr(self, 'enhanced_neurogenesis') and self.enhanced_neurogenesis:
        custom_neurons = {
            name for name, fn in self.enhanced_neurogenesis.functional_neurons.items()
            if fn.neuron_type == 'custom'
        }
    
    # Get new neurons (recently created, get learning boost)
    new_neurons = set()
    if hasattr(self, 'neurogenesis_data'):
        new_neurons = set(self.neurogenesis_data.get('new_neurons', []))
    
    # Update cache with all data including STDP settings
    self.brain_worker.update_cache(
        state=self.state,
        weights=self.weights,
        positions=self.neuron_positions,
        config=self.config,
        excluded_neurons=set(self.excluded_neurons),
        connector_neurons=connector_neurons,
        learning_rate=getattr(self, 'learning_rate', 0.1),
        new_neurons=new_neurons,
        custom_neurons=custom_neurons,
        # === NEW STDP PARAMETERS ===
        stdp_enabled=getattr(self, 'stdp_enabled', True),
        connection_ages=getattr(self, 'connection_creation_times', {})
    )


"""
================================================================================
STEP 6: Track Connection Creation Times (in weight creation methods)
================================================================================
"""

# When creating new connections, record the creation time:

def create_connection(self, source: str, target: str, weight: float = 0.1):
    """Create a new connection and track its creation time for STDP."""
    pair = (source, target)
    
    # Store the weight
    self.weights[pair] = weight
    
    # Track creation time for STDP age-based learning
    if not hasattr(self, 'connection_creation_times'):
        self.connection_creation_times = {}
    self.connection_creation_times[pair] = time.time()
    
    print(f"🔗 Created connection {source} → {target} (w={weight:.3f})")


"""
================================================================================
STEP 7: Add STDP Toggle Methods (add to BrainWidget class)
================================================================================
"""

def toggle_stdp(self, enabled: bool = None):
    """Toggle STDP learning on/off."""
    if enabled is None:
        self.stdp_enabled = not self.stdp_enabled
    else:
        self.stdp_enabled = enabled
    
    # Update worker
    if hasattr(self, 'brain_worker') and self.brain_worker:
        self.brain_worker.set_stdp_enabled(self.stdp_enabled)
    
    status = "enabled" if self.stdp_enabled else "disabled"
    print(f"🧠 STDP learning {status}")
    return self.stdp_enabled


def set_stdp_weight(self, weight: float):
    """
    Set the balance between STDP and Hebbian learning.
    
    Args:
        weight: 0.0 = pure Hebbian, 1.0 = pure STDP, 0.4 = recommended default
    """
    self.stdp_weight = max(0.0, min(1.0, weight))
    
    if hasattr(self, 'brain_worker') and self.brain_worker:
        self.brain_worker.set_stdp_weight(self.stdp_weight)
    
    print(f"🧠 Learning balance: {(1-self.stdp_weight)*100:.0f}% Hebbian, {self.stdp_weight*100:.0f}% STDP")


def get_stdp_stats(self) -> dict:
    """Get statistics about STDP learning."""
    if hasattr(self, 'brain_worker') and self.brain_worker:
        return self.brain_worker.get_stdp_stats()
    return {}


"""
================================================================================
STEP 8: Add Reward Modulation Support (for three-factor learning)
================================================================================
"""

def apply_reward_signal(self, reward: float):
    """
    Apply a reward signal to modulate recent learning through eligibility traces.
    
    This enables three-factor learning where the squid's actions are reinforced
    or weakened based on outcomes.
    
    Args:
        reward: Positive for good outcomes, negative for bad outcomes.
                Typical range: -1.0 to 1.0
    
    Example usage:
        # When squid successfully eats food:
        brain_widget.apply_reward_signal(0.5)
        
        # When squid gets sick:
        brain_widget.apply_reward_signal(-0.3)
    """
    if not hasattr(self, 'brain_worker') or not self.brain_worker:
        return
    
    self.brain_worker.queue_reward_modulation(reward)
    
    if abs(reward) > 0.1:
        sign = "+" if reward > 0 else ""
        print(f"🎯 Reward signal: {sign}{reward:.2f}")


"""
================================================================================
STEP 9: Modify update_state to Record Spikes (around line 2507)
================================================================================
"""

# In update_state(), after updating self.state but before returning,
# ADD this section to ensure spikes are recorded on every state change:

"""
        # === Record spikes for STDP ===
        if hasattr(self, 'brain_worker') and self.brain_worker:
            # The cache update will trigger spike recording in the worker
            self._update_worker_cache()
"""


"""
================================================================================
STEP 10: Drawing STDP Animations (add to paintEvent or draw methods)
================================================================================
"""

def _draw_stdp_animations(self, painter, scale):
    """
    Draw STDP learning animations showing directional causality.
    These are arrows/pulses that travel from pre to post-synaptic neurons.
    """
    if not hasattr(self, 'stdp_animations'):
        return
    
    current_time = time.time()
    surviving_animations = []
    
    for anim in self.stdp_animations:
        elapsed = current_time - anim['start_time']
        progress = elapsed / anim['duration']
        
        if progress >= 1.0:
            continue  # Animation complete
        
        surviving_animations.append(anim)
        
        source = anim['source']
        target = anim['target']
        
        if source not in self.neuron_positions or target not in self.neuron_positions:
            continue
        
        # Get positions
        x1, y1 = self.neuron_positions[source]
        x2, y2 = self.neuron_positions[target]
        x1, y1 = x1 * scale, y1 * scale
        x2, y2 = x2 * scale, y2 * scale
        
        # Interpolate position along the path
        t = progress
        px = x1 + t * (x2 - x1)
        py = y1 + t * (y2 - y1)
        
        # Fade in then out
        if progress < 0.2:
            alpha = progress / 0.2
        elif progress > 0.8:
            alpha = (1.0 - progress) / 0.2
        else:
            alpha = 1.0
        
        # Draw the traveling pulse
        r, g, b = anim['color']
        color = QtGui.QColor(r, g, b, int(200 * alpha))
        
        # Draw glow circle at current position
        painter.setBrush(QtGui.QBrush(color))
        painter.setPen(QtCore.Qt.NoPen)
        radius = 8 * scale
        painter.drawEllipse(QtCore.QPointF(px, py), radius, radius)
        
        # Draw small arrow indicating direction
        if anim['type'] == 'ltp':
            self._draw_direction_arrow(painter, px, py, x2, y2, color, scale)
    
    self.stdp_animations = surviving_animations


def _draw_direction_arrow(self, painter, x1, y1, x2, y2, color, scale):
    """Draw a small arrow pointing from (x1,y1) toward (x2,y2)."""
    import math
    
    # Calculate direction
    dx = x2 - x1
    dy = y2 - y1
    length = math.sqrt(dx*dx + dy*dy)
    
    if length < 1:
        return
    
    # Normalize
    dx /= length
    dy /= length
    
    # Arrow parameters
    arrow_length = 12 * scale
    arrow_width = 6 * scale
    
    # Arrow tip position (slightly ahead of pulse)
    tip_x = x1 + dx * arrow_length
    tip_y = y1 + dy * arrow_length
    
    # Arrow base corners
    perp_x = -dy * arrow_width / 2
    perp_y = dx * arrow_width / 2
    
    base1_x = x1 + perp_x
    base1_y = y1 + perp_y
    base2_x = x1 - perp_x
    base2_y = y1 - perp_y
    
    # Draw arrow
    arrow = QtGui.QPolygonF([
        QtCore.QPointF(tip_x, tip_y),
        QtCore.QPointF(base1_x, base1_y),
        QtCore.QPointF(base2_x, base2_y)
    ])
    
    painter.setBrush(QtGui.QBrush(color))
    painter.setPen(QtCore.Qt.NoPen)
    painter.drawPolygon(arrow)


"""
================================================================================
STEP 11: Save/Load STDP State (modify save_state and load_state methods)
================================================================================
"""

# In your save_state method, ADD:
"""
        # Save STDP state
        if hasattr(self, 'brain_worker') and self.brain_worker:
            save_data['stdp_state'] = self.brain_worker.to_dict()
        
        save_data['connection_creation_times'] = getattr(self, 'connection_creation_times', {})
        save_data['stdp_enabled'] = getattr(self, 'stdp_enabled', True)
        save_data['stdp_weight'] = getattr(self, 'stdp_weight', 0.4)
"""

# In your load_state method, ADD:
"""
        # Load STDP state
        if 'stdp_state' in data and hasattr(self, 'brain_worker') and self.brain_worker:
            self.brain_worker.from_dict(data['stdp_state'])
        
        self.connection_creation_times = data.get('connection_creation_times', {})
        self.stdp_enabled = data.get('stdp_enabled', True)
        self.stdp_weight = data.get('stdp_weight', 0.4)
"""


"""
================================================================================
USAGE EXAMPLES
================================================================================
"""

# Example 1: Enable STDP learning
# brain_widget.toggle_stdp(True)

# Example 2: Adjust learning balance (more STDP, less Hebbian)
# brain_widget.set_stdp_weight(0.6)  # 60% STDP, 40% Hebbian

# Example 3: Pure Hebbian (disable STDP)
# brain_widget.set_stdp_weight(0.0)

# Example 4: Apply reward when squid eats successfully
# def on_squid_ate_food():
#     brain_widget.apply_reward_signal(0.5)

# Example 5: Apply punishment when squid gets sick
# def on_squid_got_sick():
#     brain_widget.apply_reward_signal(-0.3)

# Example 6: Check STDP statistics
# stats = brain_widget.get_stdp_stats()
# print(f"LTP events: {stats['ltp_events']}, LTD events: {stats['ltd_events']}")


"""
================================================================================
INTEGRATION WITH TAMAGOTCHI_LOGIC (for reward signals)
================================================================================
"""

# In tamagotchi_logic.py, you can hook reward signals to behavioral outcomes:

"""
class TamagotchiLogic:
    def __init__(self, ...):
        ...
        self.brain_widget = brain_widget  # Reference to brain widget
    
    def on_successful_feeding(self):
        '''Called when squid successfully eats food'''
        if hasattr(self, 'brain_widget') and self.brain_widget:
            # Positive reward for successful behavior chain
            self.brain_widget.apply_reward_signal(0.4)
    
    def on_avoided_danger(self):
        '''Called when squid successfully flees from threat'''
        if hasattr(self, 'brain_widget') and self.brain_widget:
            self.brain_widget.apply_reward_signal(0.3)
    
    def on_got_sick(self):
        '''Called when squid becomes sick (ate bad food, etc)'''
        if hasattr(self, 'brain_widget') and self.brain_widget:
            # Negative reward - should have avoided this
            self.brain_widget.apply_reward_signal(-0.2)
    
    def on_cleaned_poop(self):
        '''Called when user cleans poop'''
        if hasattr(self, 'brain_widget') and self.brain_widget:
            # Small positive reward for cleanliness
            self.brain_widget.apply_reward_signal(0.2)
"""
