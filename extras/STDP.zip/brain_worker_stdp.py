"""
BrainWorker with STDP Integration for Dosidicus-2

This module handles background processing of expensive brain operations:
- Neurogenesis checks
- Combined Hebbian + STDP learning
- State decay and update processing
- Spike tracking for timing-dependent plasticity

Key Changes from Original:
1. Added STDPLearner integration for timing-based learning
2. Modified Hebbian learning to combine with STDP signals
3. Added spike recording during state updates
4. Added eligibility trace support for reward modulation
"""

import sys
import time
import random
import traceback
import math
from queue import Queue, Empty
from heapq import nlargest

from PyQt5.QtCore import QThread, pyqtSignal, QMutex, QMutexLocker, QWaitCondition

# Import STDP module
try:
    from .stdp import STDPLearner, STDPConfig, create_stdp_learner
except ImportError:
    from stdp import STDPLearner, STDPConfig, create_stdp_learner


# PURE_INPUTS: These neurons receive external input and should NOT be modified by learning
# They are read-only sensors that reflect game state
PURE_INPUTS = {
    "can_see_food", "is_eating", "is_sleeping", "is_sick", 
    "pursuing_food", "is_fleeing", "is_startled", "external_stimulus", 
    "plant_proximity"
}


class BrainWorker(QThread):
    """
    Background worker for handling expensive brain logic operations:
    - Neurogenesis checks
    - Hebbian + STDP learning calculations
    - State decay and update processing
    - Spike tracking for STDP
    
    Custom neurons (user-created neurons) ARE included in learning
    and can form new connections through this system.
    """
    
    # Signals for results (emitted to main thread)
    neurogenesis_result = pyqtSignal(dict)
    hebbian_result = pyqtSignal(dict)
    state_update_result = pyqtSignal(dict)
    error_occurred = pyqtSignal(str)
    
    # New signal for STDP-specific events
    stdp_event = pyqtSignal(dict)  # Emits LTP/LTD events for visualization
    
    def __init__(self, brain_widget=None, stdp_config=None):
        super().__init__()
        self.brain_widget = brain_widget
        self._running = True
        self._paused = False
        
        # Thread-safe queues for tasks
        self.task_queue = Queue()
        
        # Initialize STDP learner
        if stdp_config is None:
            stdp_config = STDPConfig(
                time_window=0.5,        # 500ms learning window
                tau_plus=0.15,          # Time constants
                tau_minus=0.15,
                A_plus=0.08,            # LTP amplitude
                A_minus=0.05,           # LTD amplitude (smaller for stability)
                stdp_weight=0.4,        # 40% STDP, 60% Hebbian
                spike_threshold=60.0,   # Spike detection threshold
                burst_bonus=1.5         # Bonus for burst activity
            )
        self.stdp_learner = STDPLearner(stdp_config)
        
        # Cache for thread-safe access to brain state
        self._cache_mutex = QMutex()
        self.cache = {
            'state': {},
            'weights': {},
            'positions': {},
            'config': None,
            'excluded_neurons': set(),
            'connector_neurons': set(),
            'custom_neurons': set(),
            'learning_rate': 0.1,
            'new_neurons': set(),
            'stdp_enabled': True,  # NEW: Toggle for STDP
            'connection_ages': {}  # NEW: Track when connections were created
        }

        # History tracking to prevent Hebbian loops
        self._last_hebbian_pairs = []
        
        # STDP statistics
        self._stdp_stats = {
            'ltp_events': 0,
            'ltd_events': 0,
            'last_learning_time': 0
        }
        
        self.wait_condition = QWaitCondition()
        self.queue_mutex = QMutex()

    def update_cache(self, state, weights, positions, config, excluded_neurons=None, 
                     connector_neurons=None, learning_rate=0.1, new_neurons=None,
                     custom_neurons=None, stdp_enabled=True, connection_ages=None):
        """
        Update the local cache of brain state.
        Called from main thread before triggering heavy tasks.
        
        Args:
            state: Current neuron activation values
            weights: Current connection weights
            positions: Neuron positions
            config: Learning configuration
            excluded_neurons: Neurons to exclude from learning (system neurons)
            connector_neurons: Connector neurons from neurogenesis
            learning_rate: Base learning rate for Hebbian updates
            new_neurons: Recently created neurons (get learning boost)
            custom_neurons: User-created custom neurons (participate in learning)
            stdp_enabled: Whether STDP learning is active
            connection_ages: Dictionary of (src, dst) -> creation_timestamp
        """
        with QMutexLocker(self._cache_mutex):
            # Deep copy or safe copy important structures
            self.cache['state'] = state.copy()
            self.cache['weights'] = weights.copy()
            self.cache['positions'] = positions.copy()
            self.cache['config'] = config
            self.cache['excluded_neurons'] = excluded_neurons if excluded_neurons else set()
            self.cache['connector_neurons'] = connector_neurons if connector_neurons else set()
            self.cache['custom_neurons'] = custom_neurons if custom_neurons else set()
            self.cache['learning_rate'] = learning_rate
            self.cache['new_neurons'] = new_neurons if new_neurons else set()
            self.cache['stdp_enabled'] = stdp_enabled
            self.cache['connection_ages'] = connection_ages if connection_ages else {}
            
        # Record spikes from current state for STDP
        self._record_spikes_from_state(state)

    def _record_spikes_from_state(self, state):
        """Record neuron activations for STDP spike detection."""
        current_time = time.time()
        spikes = self.stdp_learner.record_state(state, current_time)
        
        # Emit spike events for visualization (optional)
        if spikes:
            for neuron_name, spike_event in spikes:
                self.stdp_event.emit({
                    'type': 'spike',
                    'neuron': neuron_name,
                    'activation': spike_event.activation_level,
                    'timestamp': spike_event.timestamp
                })

    def queue_neurogenesis_check(self, state_context):
        self._add_task('neurogenesis', {'state': state_context})

    def queue_hebbian_learning(self):
        self._add_task('hebbian', {})

    def queue_state_update(self, update_data):
        self._add_task('state_update', update_data)
    
    def queue_reward_modulation(self, reward_signal):
        """Queue a reward signal to modulate eligibility traces."""
        self._add_task('reward', {'signal': reward_signal})

    def _add_task(self, task_type, data):
        with QMutexLocker(self.queue_mutex):
            self.task_queue.put((task_type, data))
            self.wait_condition.wakeOne()

    def stop(self):
        self._running = False
        with QMutexLocker(self.queue_mutex):
            self.wait_condition.wakeAll()

    def pause(self):
        """Pause the worker thread."""
        with QMutexLocker(self.queue_mutex):
            self._paused = True
    
    def resume(self):
        """Resume the worker thread."""
        with QMutexLocker(self.queue_mutex):
            self._paused = False
            self.wait_condition.wakeAll()
    
    def set_stdp_enabled(self, enabled: bool):
        """Enable or disable STDP learning."""
        with QMutexLocker(self._cache_mutex):
            self.cache['stdp_enabled'] = enabled
        print(f"🧠 STDP learning {'enabled' if enabled else 'disabled'}")
    
    def set_stdp_weight(self, weight: float):
        """Set the STDP vs Hebbian weight ratio (0-1)."""
        self.stdp_learner.config.stdp_weight = max(0.0, min(1.0, weight))
        print(f"🧠 STDP weight set to {weight:.2f}")

    def run(self):
        print("🧵 BrainWorker thread started (with STDP)")
        
        # Periodic STDP cleanup counter
        cleanup_counter = 0
        
        while self._running:
            task = None
            
            # Wait for task
            with QMutexLocker(self.queue_mutex):
                # Check pause state first
                while self._paused and self._running:
                    self.wait_condition.wait(self.queue_mutex)

                if not self._running:
                    break

                if self.task_queue.empty():
                    self.wait_condition.wait(self.queue_mutex, 200)
                    if self._paused: 
                        continue
                    if self.task_queue.empty():
                        continue
                
                try:
                    task = self.task_queue.get_nowait()
                except Empty:
                    continue

            if not task:
                continue

            task_type, data = task
            
            try:
                if task_type == 'neurogenesis':
                    self._perform_neurogenesis_check(data)
                elif task_type == 'hebbian':
                    self._perform_hebbian_learning()
                elif task_type == 'state_update':
                    self._process_state_update(data)
                elif task_type == 'reward':
                    self._process_reward_modulation(data)
            except Exception as e:
                error_msg = f"Error in {task_type}: {str(e)}\n{traceback.format_exc()}"
                print(error_msg)
                self.error_occurred.emit(error_msg)
            
            # Periodic cleanup
            cleanup_counter += 1
            if cleanup_counter >= 50:
                self.stdp_learner.cleanup()
                cleanup_counter = 0
                
        print("🧵 BrainWorker thread stopped")

    def _perform_neurogenesis_check(self, data):
        """Check if neurogenesis conditions are met based on cached config."""
        state = data.get('state', {})
        
        with QMutexLocker(self._cache_mutex):
            config = self.cache['config']
        
        if not config:
            return

        neuro_config = getattr(config, 'neurogenesis', {})
        
        triggers = {
            'novelty': state.get('novelty_exposure', 0) > neuro_config.get('novelty_threshold', 3.0),
            'stress': state.get('sustained_stress', 0) > neuro_config.get('stress_threshold', 1.2) or state.get('anxiety', 0) > 75,
            'reward': state.get('recent_rewards', 0) > neuro_config.get('reward_threshold', 3.5)
        }
        
        # Priority logic
        trigger_type = None
        trigger_val = 0
        
        if triggers['stress']:
            trigger_type = 'stress'
            trigger_val = state.get('sustained_stress', 0)
        elif triggers['novelty']:
            trigger_type = 'novelty'
            trigger_val = state.get('novelty_exposure', 0)
        elif triggers['reward']:
            trigger_type = 'reward'
            trigger_val = state.get('recent_rewards', 0)
            
        if trigger_type:
            self.neurogenesis_result.emit({
                'should_create': True,
                'neuron_type': trigger_type,
                'trigger_value': trigger_val,
                'state_context': state,
                'is_emergency': (trigger_type == 'stress' and state.get('anxiety', 0) > 90)
            })
        else:
            self.neurogenesis_result.emit({'should_create': False})

    def _perform_hebbian_learning(self):
        """
        Combined Hebbian + STDP learning.
        
        This method integrates:
        1. Rate-based Hebbian learning (neurons that fire together wire together)
        2. STDP timing-based learning (causal relationships strengthen connections)
        
        The relative contribution is controlled by stdp_weight in the config.
        """
        with QMutexLocker(self._cache_mutex):
            state = self.cache['state']
            weights = self.cache['weights']
            neuron_list = list(self.cache['positions'].keys())
            excluded = self.cache['excluded_neurons']
            connector_neurons = self.cache['connector_neurons']
            custom_neurons = self.cache['custom_neurons']
            config = self.cache['config']
            base_learning_rate = self.cache['learning_rate']
            new_neurons = self.cache['new_neurons']
            stdp_enabled = self.cache['stdp_enabled']
            connection_ages = self.cache['connection_ages']

        if not config or not neuron_list:
            return

        # Filter to learning candidates
        learning_candidates = [
            n for n in neuron_list 
            if n not in excluded and n not in connector_neurons and n not in PURE_INPUTS
        ]
        
        if len(learning_candidates) < 2:
            self.hebbian_result.emit({'updated_pairs': []})
            return

        # Score neuron pairs for learning
        scored_pairs = []
        current_time = time.time()
        
        for i, n1 in enumerate(learning_candidates):
            for n2 in learning_candidates[i + 1:]:
                v1 = self._get_neuron_value(state.get(n1, 50))
                v2 = self._get_neuron_value(state.get(n2, 50))
                
                # Base score from activation levels
                score = v1 + v2 + random.uniform(0, 40)

                # Penalize recently updated pairs
                pair_key = tuple(sorted((n1, n2)))
                if pair_key in self._last_hebbian_pairs:
                    score -= 500
                
                # Boost custom neurons
                if n1 in custom_neurons or n2 in custom_neurons:
                    score += 15
                
                # STDP timing bonus: pairs with recent spikes get priority
                if stdp_enabled:
                    t1 = self.stdp_learner.spike_tracker.get_last_spike_time(n1)
                    t2 = self.stdp_learner.spike_tracker.get_last_spike_time(n2)
                    if t1 and t2:
                        # Both neurons spiked recently - high priority
                        recency = max(0, 1.0 - (current_time - max(t1, t2)))
                        score += recency * 30
                        
                        # Temporal causality bonus (one fired then the other)
                        dt = abs(t2 - t1)
                        if 0.05 < dt < 0.5:  # Within STDP window but not simultaneous
                            score += 20

                scored_pairs.append((score, n1, n2, v1, v2))

        # Select top pairs for learning
        top_k = config.neurogenesis.get('max_hebbian_pairs', 2) if hasattr(config, 'neurogenesis') else 2
        top_pairs = nlargest(top_k, scored_pairs)
        self._last_hebbian_pairs = [tuple(sorted((n1, n2))) for _, n1, n2, _, _ in top_pairs]
        
        # Compute weight updates
        weight_updates = {}
        updated_pairs_list = []
        hebbian_config = getattr(config, 'hebbian', {})
        decay_rate = hebbian_config.get('weight_decay', 0.01)
        
        ltp_count = 0
        ltd_count = 0
        
        for _, n1, n2, v1, v2 in top_pairs:
            pair = (n1, n2)
            reverse_pair = (n2, n1)
            
            # --- ROBUST WEIGHT LOOKUP ---
            use_pair = None
            if pair in weights:
                use_pair = pair
            elif reverse_pair in weights:
                use_pair = reverse_pair
            
            is_new = False
            if use_pair is None:
                use_pair = pair
                old_w = 0.0
                is_new = True
            else:
                old_w = weights[use_pair]
            
            # Calculate connection age (0 = brand new, 1 = old)
            creation_time = connection_ages.get(use_pair, connection_ages.get(reverse_pair, 0))
            if creation_time > 0:
                age = min(1.0, (current_time - creation_time) / 300.0)  # Normalize to 5 minutes
            else:
                age = 1.0 if not is_new else 0.0
            
            # Check if either neuron is custom
            is_custom = n1 in custom_neurons or n2 in custom_neurons
            
            # Calculate learning rate with boosts
            lr = base_learning_rate
            if n1 in new_neurons or n2 in new_neurons:
                lr *= 2.0
            if is_custom:
                lr *= 1.5
            
            # === COMBINED HEBBIAN + STDP LEARNING ===
            if stdp_enabled:
                # Use combined learning from STDP module
                combined_delta, metadata = self.stdp_learner.compute_combined_learning(
                    n1, n2, v1, v2,
                    base_learning_rate=lr,
                    connection_age=age,
                    is_custom=is_custom
                )
                
                delta = combined_delta
                
                # Track LTP/LTD events
                if metadata['is_ltp']:
                    ltp_count += 1
                elif metadata['is_ltd']:
                    ltd_count += 1
                
                # Emit STDP event for visualization
                if metadata['stdp_delta'] != 0:
                    self.stdp_event.emit({
                        'type': 'learning',
                        'neurons': (n1, n2),
                        'direction': metadata['stdp_direction'],
                        'is_ltp': metadata['is_ltp'],
                        'is_ltd': metadata['is_ltd'],
                        'hebbian_delta': metadata['hebbian_delta'],
                        'stdp_delta': metadata['stdp_delta'],
                        'combined_delta': metadata['combined_delta']
                    })
            else:
                # Pure Hebbian (original behavior)
                delta = lr * (v1 / 100.0) * (v2 / 100.0)
            
            # Apply weight decay
            new_w = old_w + delta - (old_w * decay_rate)
            
            # Clamp weight
            new_w = max(-1.0, min(1.0, new_w))
            
            weight_updates[use_pair] = {
                'old_weight': old_w,
                'new_weight': new_w,
                'is_new_connection': is_new,
                'stdp_contribution': metadata['stdp_delta'] if stdp_enabled else 0,
                'hebbian_contribution': metadata['hebbian_delta'] if stdp_enabled else delta
            }
            updated_pairs_list.append(use_pair)

        # Update statistics
        self._stdp_stats['ltp_events'] += ltp_count
        self._stdp_stats['ltd_events'] += ltd_count
        self._stdp_stats['last_learning_time'] = current_time

        # Emit results
        self.hebbian_result.emit({
            'updated_pairs': updated_pairs_list,
            'weight_updates': weight_updates,
            'stdp_stats': {
                'ltp_count': ltp_count,
                'ltd_count': ltd_count,
                'stdp_enabled': stdp_enabled
            }
        })

    def _process_reward_modulation(self, data):
        """
        Process reward signal to modulate eligibility traces.
        
        This implements three-factor learning: connections that were recently
        active (have eligibility traces) get their weights modified based on
        the reward signal.
        """
        reward_signal = data.get('signal', 0.0)
        
        if abs(reward_signal) < 0.01:
            return
        
        # Apply reward to eligibility traces
        weight_deltas = self.stdp_learner.apply_reward_modulation(reward_signal)
        
        if weight_deltas:
            self.hebbian_result.emit({
                'updated_pairs': list(weight_deltas.keys()),
                'weight_updates': {
                    pair: {'delta': delta, 'reward_modulated': True}
                    for pair, delta in weight_deltas.items()
                },
                'reward_signal': reward_signal
            })

    def _process_state_update(self, data):
        """Process state decay and noise logic, with STDP spike recording."""
        if data.get('health_check'):
            self.state_update_result.emit({'health_check': True})
            return

        with QMutexLocker(self._cache_mutex):
            current_state = self.cache['state']
            weights = self.cache['weights']
            excluded = self.cache['excluded_neurons']
            custom_neurons = self.cache['custom_neurons']

        # Record spikes from current state
        self._record_spikes_from_state(current_state)

        updated_state = {}

        # 1. Decay and Noise
        for neuron, val in current_state.items():
            if neuron in excluded or neuron in PURE_INPUTS:
                continue
            
            if isinstance(val, (int, float)):
                # Decay factor
                decay = 0.95 
                noise = random.uniform(-0.5, 0.5)
                
                # Custom neurons decay slower
                if neuron in custom_neurons:
                    decay = 0.97
                
                new_val = val * decay + noise
                updated_state[neuron] = new_val

        # 2. Connection effects
        connection_deltas = {}
        
        for (src, dst), w in weights.items():
            if src in current_state and dst in current_state:
                if dst in PURE_INPUTS: 
                    continue
                
                src_val = current_state[src]
                if isinstance(src_val, (int, float)):
                    effect = src_val * w * 0.1
                    connection_deltas[dst] = connection_deltas.get(dst, 0) + effect
                    
        # Apply deltas
        for neuron, delta in connection_deltas.items():
            if neuron in updated_state:
                updated_state[neuron] += delta
            elif neuron in current_state and neuron not in PURE_INPUTS:
                updated_state[neuron] = current_state[neuron] + delta

        # Clamp
        final_state = {}
        for k, v in updated_state.items():
            final_state[k] = max(-100, min(100, v))

        self.state_update_result.emit({'processed_state': final_state})

    def _get_neuron_value(self, val):
        """Convert various value types to float for calculations."""
        if isinstance(val, (int, float)):
            return float(val)
        if isinstance(val, bool):
            return 100.0 if val else 0.0
        return 0.0
    
    def get_stdp_stats(self) -> dict:
        """Get STDP learning statistics."""
        learner_stats = self.stdp_learner.get_stats()
        return {
            **self._stdp_stats,
            **learner_stats
        }
    
    def reset_stdp_stats(self):
        """Reset STDP statistics."""
        self._stdp_stats = {
            'ltp_events': 0,
            'ltd_events': 0,
            'last_learning_time': 0
        }
        self.stdp_learner.reset_stats()
    
    def get_stdp_learner(self) -> STDPLearner:
        """Get reference to STDP learner for direct configuration."""
        return self.stdp_learner
    
    def to_dict(self) -> dict:
        """Serialize worker state including STDP data."""
        return {
            'stdp_learner': self.stdp_learner.to_dict(),
            'stdp_stats': self._stdp_stats.copy(),
            'last_hebbian_pairs': list(self._last_hebbian_pairs)
        }
    
    def from_dict(self, data: dict):
        """Restore worker state from saved data."""
        if 'stdp_learner' in data:
            self.stdp_learner.from_dict(data['stdp_learner'])
        if 'stdp_stats' in data:
            self._stdp_stats = data['stdp_stats']
        if 'last_hebbian_pairs' in data:
            self._last_hebbian_pairs = [tuple(p) for p in data['last_hebbian_pairs']]
